The file A1Report.docx has the report
The file sol1.c has the implementation for  the producer-consumer problem
The file sol2.c has the implementation for the dining philosopher's problem

the `make all` command will build both implementations.

./implementation_1 will run implementation 1, which is the algorithm A
and ./implementation_2 will run implementation 2, which is the algorithm C

The clean command will clean up the built files, if you wish to rebuild them.